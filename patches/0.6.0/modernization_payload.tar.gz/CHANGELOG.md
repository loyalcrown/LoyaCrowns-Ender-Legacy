# Changelog

## 0.6.0-alpha — Modern machine controls / Farming Station backport

- Backported the official Ender IO 1.21.1 Farming Station block appearance to the 1.20.1 restoration.
- Added shared persisted redstone control modes: Always Active, Active With Signal, Active Without Signal, and Never Active.
- Added shared per-face item and energy IO configuration infrastructure.
- Farming Station now exposes functional redstone and side-configuration controls in its GUI.
- Farming Station automation honors configured item/power faces, and redstone control actually pauses farming.
- Preserved the 1.12-style Farming Station model as a legacy resource for future skin selection/resource-pack support.


## 0.2.0-alpha
- Switched the visual reference forward to Ender IO 1.12.2-5.3.72 where applicable.
- Fixed Dark Steel Anvil geometry/texture.
- Fixed Ender Rail blockstate coverage and restored original Ender Rail art.
- Added 1.12.2 Exit Rail with legacy eject/destroy behavior.
- Added Graphical Power Monitor with 1.12.2 animated display art.
- Added Dark Paper Anvil.
- Added Frank'n'Zombie Generator and Ender Generator with 5.3.72 fuel/generation defaults.
- Farming Station now uses its exact 5.3.72 block geometry, not a cube approximation.
- Updated several existing machine textures to their 1.12.2 versions.
- Added automated missing-model/missing-texture validation.
- Kept Minecraft 1.20.1, Forge 47.4.x, Java 17, and Ender IO 6.2.15-beta compatibility target.

## 0.1.1-alpha
- Expanded Farming Station crop/tree handling and output routing.

## 0.3.0-alpha — comprehensive 1.12.2 content pass
- Added 48 missing core legacy blocks/machines found in Ender IO 5.3.72 after a modern-content duplicate audit.
- Added 141 missing legacy items/components/tools/armor/upgrades and alloy forms.
- Added functional storage, Inventory Panel network access, Telepad channels, obelisks, Lava Heat Exchanger, Niard, processors, charger tiers, Creative Spawner, gauges/detectors and legacy charges.
- Kept modern Ender IO equivalents out of the addon to avoid duplicate machines/items.
- Added PORT_MANIFEST_1_12_2.json documenting restored vs deliberately non-duplicated content.

## 0.4.0-alpha — deep functional parity
- Added the five missing 1.12.2 Simple machine tiers after confirming they are absent from Ender IO 6.2.15-beta.
- Added exact 5.3.72 Simple-machine textures and resource models.
- Added functional Simple Stirling Generator, Simple SAG Mill, Simple Alloy Smelter, Simple Crafter, and Simple Wired Charger.
- Inventory Panel now opens a 54-slot live network inventory menu.
- Basic/Advanced/Ender Inventory Remotes now link to panels and use the original 80-block / same-dimension / interdimensional tier rules.
- Kept modern full-tier Ender IO machines authoritative; no duplicate modern Alloy Smelter/SAG Mill/Crafter/etc. was added.

## 0.5.4-alpha
- Restored the Inventory Panel's 3x3 crafting matrix and crafting-result slot.
- Added a five-slot return buffer that automatically reinserts items into the connected storage network.
- Shift-clicking network items now targets the player inventory without contaminating crafting/return slots.
- Crafting and return-buffer leftovers are safely returned to the storage network when the GUI closes.
## 0.5.5-alpha
- Added ten stored crafting recipe memories with one-craft and fill-stack refill modes.

## 0.5.6-alpha
- Restored Inventory Panel filter-card support with learn/clear controls and persistent card configuration.

## 0.5.7-alpha — Inventory Panel nutrient power
- Restored the 5.3.72 Inventory Panel Nutrient Distillation tank (2,000 mB).
- Restored the 5.3.72 internal panel-power conversion rate of 800 power per mB.
- Network scans now consume legacy-style power per scanned slot and the panel goes offline when it cannot pay the scan cost.
- Item extraction now consumes an operation cost plus a per-item power cost and is limited by available Nutrient Distillation.
- The Inventory Panel now exposes a fill-only fluid capability for Nutrient Distillation and no longer accepts external FE as its operating power.
- The Inventory Panel GUI now reports online/offline state, nutrient level, and internal panel power.

