package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.util.EnergyTransferUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ZombieGeneratorBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    private final FluidTank nutrientTank = new FluidTank(8_000, this::isNutrient) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private LazyOptional<IFluidHandler> fluidCapability = LazyOptional.empty();
    private int fuelCounter;

    public ZombieGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.ZOMBIE_GENERATOR.get(), pos, state, 500_000, 0, 4_000);
    }

    private boolean isNutrient(FluidStack stack) {
        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(stack.getFluid());
        return id != null && id.getNamespace().equals("enderio") && id.getPath().equals("nutrient_distillation");
    }

    @Override
    public void onLoad() {
        super.onLoad();
        fluidCapability = LazyOptional.of(() -> nutrientTank);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        fluidCapability.invalidate();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.FLUID_HANDLER) return fluidCapability.cast();
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide) return;
        if (!nutrientTank.isEmpty() && energy.getEnergyStored() <= energy.getMaxEnergyStored() - 80) {
            energy.addEnergyInternal(80, false);
            if (++fuelCounter >= 10) {
                fuelCounter = 0;
                nutrientTank.drain(1, IFluidHandler.FluidAction.EXECUTE);
            }
            setChanged();
        }
        EnergyTransferUtil.pushEnergy(level, worldPosition, energy, 1_000);
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (FluidUtil.interactWithFluidHandler(player, hand, nutrientTank)) return InteractionResult.CONSUME;
        player.displayClientMessage(Component.literal("Zombie Generator — " + energy.getEnergyStored() + " FE | Nutrient Distillation "
                + nutrientTank.getFluidAmount() + "/" + nutrientTank.getCapacity() + " mB | 80 FE/t"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Nutrient", nutrientTank.writeToNBT(new CompoundTag()));
        tag.putInt("FuelCounter", fuelCounter);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        nutrientTank.readFromNBT(tag.getCompound("Nutrient"));
        fuelCounter = tag.getInt("FuelCounter");
    }
}
