package com.loyacrown.enderlegacy.util;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;

public final class MachineInteractionUtil {
    public static InteractionResult insertOrExtract(Player player, InteractionHand hand, ItemStackHandler inventory, String status) {
        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty()) {
            ItemStack original = held.copy();
            ItemStack remainder = ItemHandlerHelper.insertItemStacked(inventory, original, false);
            int inserted = original.getCount() - remainder.getCount();
            if (inserted > 0) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(inserted);
                }
                player.displayClientMessage(Component.literal(status), true);
                return InteractionResult.sidedSuccess(player.level().isClientSide);
            }
        } else if (player.isShiftKeyDown()) {
            for (int i = inventory.getSlots() - 1; i >= 0; i--) {
                ItemStack extracted = inventory.extractItem(i, 64, false);
                if (!extracted.isEmpty()) {
                    if (!player.addItem(extracted)) {
                        player.drop(extracted, false);
                    }
                    player.displayClientMessage(Component.literal(status), true);
                    return InteractionResult.sidedSuccess(player.level().isClientSide);
                }
            }
        }
        player.displayClientMessage(Component.literal(status + "  (Insert items normally; shift-right-click empty-handed to extract.)"), true);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    private MachineInteractionUtil() {}
}
