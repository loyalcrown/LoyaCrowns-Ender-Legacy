package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.util.MachineInteractionUtil;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.UUID;

public class KillerJoeBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity
        implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity, LegacyInventoryHolder {
    private static final GameProfile PROFILE = new GameProfile(UUID.fromString("a8fcf04a-7e3b-4c21-a7a7-7f8e19bca991"), "[KillerJoe]");

    private final ItemStackHandler inventory = new ItemStackHandler(1) {
        @Override public boolean isItemValid(int slot, @NotNull ItemStack stack) { return stack.getItem() instanceof SwordItem; }
        @Override protected void onContentsChanged(int slot) { setChanged(); }
    };
    private final FluidTank nutrientTank = new FluidTank(8_000, this::isNutrient) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private final FluidTank xpTank = new FluidTank(8_000, this::isXpJuice) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private final IFluidHandler fluids = new JoeFluidHandler();
    private LazyOptional<ItemStackHandler> itemCapability = LazyOptional.empty();
    private LazyOptional<IFluidHandler> fluidCapability = LazyOptional.empty();
    private int tickCounter;

    public KillerJoeBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.KILLER_JOE.get(), pos, state);
    }

    private boolean isNutrient(FluidStack stack) {
        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(stack.getFluid());
        return id != null && id.getNamespace().equals("enderio") && id.getPath().equals("nutrient_distillation");
    }

    private boolean isXpJuice(FluidStack stack) {
        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(stack.getFluid());
        return id != null && id.getNamespace().equals("enderio") && id.getPath().equals("xp_juice");
    }

    @Override
    public void onLoad() {
        super.onLoad();
        itemCapability = LazyOptional.of(() -> inventory);
        fluidCapability = LazyOptional.of(() -> fluids);
    }

    @Override
    public void invalidateCaps() {
        itemCapability.invalidate();
        fluidCapability.invalidate();
        super.invalidateCaps();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return itemCapability.cast();
        if (cap == ForgeCapabilities.FLUID_HANDLER) return fluidCapability.cast();
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (!(level instanceof ServerLevel serverLevel) || ++tickCounter < 20) return;
        tickCounter = 0;
        ItemStack sword = inventory.getStackInSlot(0);
        if (sword.isEmpty() || nutrientTank.getFluidAmount() < 5) return;

        Mob target = serverLevel.getEntitiesOfClass(Mob.class, new AABB(worldPosition).inflate(4.0), LivingEntity::isAlive)
                .stream().min(Comparator.comparingDouble(m -> m.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5)))
                .orElse(null);
        if (target == null) return;

        FakePlayer fake = FakePlayerFactory.get(serverLevel, PROFILE);
        fake.setPos(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5);
        fake.setItemInHand(InteractionHand.MAIN_HAND, sword.copy());
        fake.resetAttackStrengthTicker();
        float healthBefore = target.getHealth();
        fake.attack(target);
        inventory.setStackInSlot(0, fake.getMainHandItem().copy());
        fake.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        if (target.getHealth() < healthBefore) {
            nutrientTank.drain(5, IFluidHandler.FluidAction.EXECUTE);
            if (!target.isAlive()) {
                Fluid xp = ForgeRegistries.FLUIDS.getValue(new ResourceLocation("enderio", "xp_juice"));
                if (xp != null && xp != Fluids.EMPTY) xpTank.fill(new FluidStack(xp, 20), IFluidHandler.FluidAction.EXECUTE);
            }
            setChanged();
        }
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (FluidUtil.interactWithFluidHandler(player, hand, fluids)) return InteractionResult.CONSUME;
        String status = "Killer Joe — Nutrient Distillation " + nutrientTank.getFluidAmount() + " mB | Liquid XP "
                + xpTank.getFluidAmount() + " mB | sword: " + (inventory.getStackInSlot(0).isEmpty() ? "none" : inventory.getStackInSlot(0).getHoverName().getString());
        if (player.getItemInHand(hand).isEmpty() && !player.isShiftKeyDown()) {
            player.displayClientMessage(Component.literal(status), true);
            return InteractionResult.CONSUME;
        }
        return MachineInteractionUtil.insertOrExtract(player, hand, inventory, status);
    }

    @Override public ItemStackHandler getInventory() { return inventory; }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inventory", inventory.serializeNBT());
        tag.put("Nutrient", nutrientTank.writeToNBT(new CompoundTag()));
        tag.put("XP", xpTank.writeToNBT(new CompoundTag()));
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        inventory.deserializeNBT(tag.getCompound("Inventory"));
        nutrientTank.readFromNBT(tag.getCompound("Nutrient"));
        xpTank.readFromNBT(tag.getCompound("XP"));
    }

    private class JoeFluidHandler implements IFluidHandler {
        @Override public int getTanks() { return 2; }
        @Override public @NotNull FluidStack getFluidInTank(int tank) { return tank == 0 ? nutrientTank.getFluid() : xpTank.getFluid(); }
        @Override public int getTankCapacity(int tank) { return tank == 0 ? nutrientTank.getCapacity() : xpTank.getCapacity(); }
        @Override public boolean isFluidValid(int tank, @NotNull FluidStack stack) { return tank == 0 && nutrientTank.isFluidValid(stack); }
        @Override public int fill(FluidStack resource, FluidAction action) { return nutrientTank.fill(resource, action); }
        @Override public @NotNull FluidStack drain(FluidStack resource, FluidAction action) { return xpTank.drain(resource, action); }
        @Override public @NotNull FluidStack drain(int maxDrain, FluidAction action) { return xpTank.drain(maxDrain, action); }
    }
}
