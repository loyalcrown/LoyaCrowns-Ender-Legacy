package com.loyacrown.enderlegacy.util;

import com.loyacrown.enderlegacy.blockentity.DimensionalTransceiverBlockEntity;
import net.minecraft.server.MinecraftServer;

import java.util.*;
import java.util.function.Predicate;

public final class DimensionalTransceiverNetwork {
    private static final Map<MinecraftServer, Map<String, Set<DimensionalTransceiverBlockEntity>>> NETWORKS = new WeakHashMap<>();

    public static synchronized void register(DimensionalTransceiverBlockEntity blockEntity) {
        MinecraftServer server = blockEntity.getServer();
        if (server == null) return;
        NETWORKS.computeIfAbsent(server, s -> new HashMap<>())
                .computeIfAbsent(blockEntity.getChannel(), c -> Collections.newSetFromMap(new WeakHashMap<>()))
                .add(blockEntity);
    }

    public static synchronized void unregister(DimensionalTransceiverBlockEntity blockEntity) {
        MinecraftServer server = blockEntity.getServer();
        if (server == null) return;
        Map<String, Set<DimensionalTransceiverBlockEntity>> channels = NETWORKS.get(server);
        if (channels == null) return;
        for (Set<DimensionalTransceiverBlockEntity> set : channels.values()) {
            set.remove(blockEntity);
        }
    }

    public static synchronized DimensionalTransceiverBlockEntity findPeer(DimensionalTransceiverBlockEntity source,
                                                                           Predicate<DimensionalTransceiverBlockEntity> predicate) {
        MinecraftServer server = source.getServer();
        if (server == null) return null;
        Map<String, Set<DimensionalTransceiverBlockEntity>> channels = NETWORKS.get(server);
        if (channels == null) return null;
        Set<DimensionalTransceiverBlockEntity> nodes = channels.get(source.getChannel());
        if (nodes == null) return null;
        nodes.removeIf(be -> be == null || be.isRemoved());
        for (DimensionalTransceiverBlockEntity candidate : nodes) {
            if (candidate != source && predicate.test(candidate)) return candidate;
        }
        return null;
    }

    private DimensionalTransceiverNetwork() {}
}
