package com.loyacrown.enderlegacy.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class LegacyEnderIOBlock extends Block {
    public LegacyEnderIOBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (BlockPos scan : BlockPos.betweenClosed(pos.offset(-4, -4, -4), pos.offset(4, 4, 4))) {
            if (scan.equals(pos)) continue;
            BlockEntity be = level.getBlockEntity(scan);
            if (be instanceof MenuProvider) {
                double d = scan.distSqr(pos);
                if (d < nearestDistance) {
                    nearestDistance = d;
                    nearest = be;
                }
            }
        }
        if (nearest instanceof MenuProvider provider) {
            player.openMenu(provider);
            player.displayClientMessage(Component.literal("Ender IO: opened nearest accessible machine."), true);
        } else {
            player.displayClientMessage(Component.literal("Ender IO: no accessible machine found within 4 blocks."), true);
        }
        return InteractionResult.CONSUME;
    }
}
