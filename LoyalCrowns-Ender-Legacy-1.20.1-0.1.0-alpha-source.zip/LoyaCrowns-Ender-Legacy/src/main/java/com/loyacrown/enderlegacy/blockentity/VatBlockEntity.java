package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.util.MachineInteractionUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Set;

public class VatBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity,
        LegacyInteractableBlockEntity, LegacyInventoryHolder {
    private static final int RECIPE_TIME = 200;
    private static final int ENERGY_PER_TICK = 50;

    private final ItemStackHandler inventory = new ItemStackHandler(2) {
        @Override protected void onContentsChanged(int slot) { setChanged(); }
    };
    private final FluidTank inputTank = new FluidTank(8_000, this::validInputFluid) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private final FluidTank outputTank = new FluidTank(8_000) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private final IFluidHandler fluidHandler = new VatFluidHandler();
    private LazyOptional<ItemStackHandler> itemCapability = LazyOptional.empty();
    private LazyOptional<IFluidHandler> fluidCapability = LazyOptional.empty();
    private int progress;
    private RecipeKind activeRecipe;

    private enum RecipeKind {
        NUTRIENT("nutrient_distillation"),
        HOOTCH("hootch"),
        ROCKET_FUEL("rocket_fuel"),
        FIRE_WATER("fire_water");
        final String output;
        RecipeKind(String output) { this.output = output; }
    }

    public VatBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.THE_VAT.get(), pos, state, 100_000, 2_000, 0);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        itemCapability = LazyOptional.of(() -> inventory);
        fluidCapability = LazyOptional.of(() -> fluidHandler);
    }

    @Override
    public void invalidateCaps() {
        itemCapability.invalidate();
        fluidCapability.invalidate();
        super.invalidateCaps();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return itemCapability.cast();
        if (cap == ForgeCapabilities.FLUID_HANDLER) return fluidCapability.cast();
        return super.getCapability(cap, side);
    }

    private boolean validInputFluid(FluidStack stack) {
        if (stack.getFluid() == Fluids.WATER) return true;
        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(stack.getFluid());
        return id != null && id.getNamespace().equals("enderio") && id.getPath().equals("hootch");
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide) return;
        RecipeKind recipe = findRecipe();
        if (recipe == null || !canOutput(recipe)) {
            progress = 0;
            activeRecipe = null;
            return;
        }
        if (activeRecipe != recipe) {
            progress = 0;
            activeRecipe = recipe;
        }
        if (energy.extractEnergy(ENERGY_PER_TICK, true) < ENERGY_PER_TICK) return;
        energy.extractEnergy(ENERGY_PER_TICK, false);
        progress++;
        if (progress >= RECIPE_TIME) {
            completeRecipe(recipe);
            progress = 0;
            activeRecipe = null;
        }
        setChanged();
    }

    private RecipeKind findRecipe() {
        if (inputTank.getFluidAmount() < 1_000) return null;
        ItemStack a = inventory.getStackInSlot(0);
        ItemStack b = inventory.getStackInSlot(1);
        if (a.isEmpty() || b.isEmpty()) return null;
        ResourceLocation fluidId = ForgeRegistries.FLUIDS.getKey(inputTank.getFluid().getFluid());
        boolean water = inputTank.getFluid().getFluid() == Fluids.WATER;
        boolean hootch = fluidId != null && fluidId.getNamespace().equals("enderio") && fluidId.getPath().equals("hootch");

        if (water && isOneOf(a.getItem(), Items.ROTTEN_FLESH, Items.CHICKEN, Items.BEEF, Items.PORKCHOP)
                && isOneOf(b.getItem(), Items.SUGAR, Items.BROWN_MUSHROOM, Items.RED_MUSHROOM, Items.NETHER_WART, Items.FERMENTED_SPIDER_EYE)) {
            return RecipeKind.NUTRIENT;
        }
        if (water && isOneOf(a.getItem(), Items.POISONOUS_POTATO, Items.POTATO, Items.APPLE, Items.WHEAT, Items.WHEAT_SEEDS)
                && b.is(Items.SUGAR)) {
            return RecipeKind.HOOTCH;
        }
        if (hootch && a.is(Items.GUNPOWDER) && b.is(Items.REDSTONE)) return RecipeKind.ROCKET_FUEL;
        if (hootch && a.is(Items.BLAZE_POWDER) && b.is(Items.REDSTONE)) return RecipeKind.FIRE_WATER;
        return null;
    }

    private boolean isOneOf(Item item, Item... choices) {
        for (Item choice : choices) if (item == choice) return true;
        return false;
    }

    private boolean canOutput(RecipeKind recipe) {
        Fluid outputFluid = ForgeRegistries.FLUIDS.getValue(new ResourceLocation("enderio", recipe.output));
        if (outputFluid == null || outputFluid == Fluids.EMPTY) return false;
        FluidStack output = new FluidStack(outputFluid, 1_000);
        return outputTank.fill(output, IFluidHandler.FluidAction.SIMULATE) == 1_000;
    }

    private void completeRecipe(RecipeKind recipe) {
        Fluid outputFluid = ForgeRegistries.FLUIDS.getValue(new ResourceLocation("enderio", recipe.output));
        if (outputFluid == null || outputFluid == Fluids.EMPTY) return;
        inventory.extractItem(0, 1, false);
        inventory.extractItem(1, 1, false);
        inputTank.drain(1_000, IFluidHandler.FluidAction.EXECUTE);
        outputTank.fill(new FluidStack(outputFluid, 1_000), IFluidHandler.FluidAction.EXECUTE);
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (FluidUtil.interactWithFluidHandler(player, hand, fluidHandler)) return InteractionResult.CONSUME;
        String status = "The Vat — " + energy.getEnergyStored() + " FE | input " + inputTank.getFluidAmount()
                + " mB | output " + outputTank.getFluidAmount() + " mB | progress " + progress + "/" + RECIPE_TIME;
        if (player.getItemInHand(hand).isEmpty() && !player.isShiftKeyDown()) {
            player.displayClientMessage(Component.literal(status), true);
            return InteractionResult.CONSUME;
        }
        return MachineInteractionUtil.insertOrExtract(player, hand, inventory, status);
    }

    @Override
    public ItemStackHandler getInventory() {
        return inventory;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inventory", inventory.serializeNBT());
        tag.put("InputTank", inputTank.writeToNBT(new CompoundTag()));
        tag.put("OutputTank", outputTank.writeToNBT(new CompoundTag()));
        tag.putInt("Progress", progress);
        if (activeRecipe != null) tag.putString("Recipe", activeRecipe.name());
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        inventory.deserializeNBT(tag.getCompound("Inventory"));
        inputTank.readFromNBT(tag.getCompound("InputTank"));
        outputTank.readFromNBT(tag.getCompound("OutputTank"));
        progress = tag.getInt("Progress");
        try { activeRecipe = tag.contains("Recipe") ? RecipeKind.valueOf(tag.getString("Recipe")) : null; }
        catch (IllegalArgumentException ignored) { activeRecipe = null; }
    }

    private class VatFluidHandler implements IFluidHandler {
        @Override public int getTanks() { return 2; }
        @Override public @NotNull FluidStack getFluidInTank(int tank) { return tank == 0 ? inputTank.getFluid() : outputTank.getFluid(); }
        @Override public int getTankCapacity(int tank) { return tank == 0 ? inputTank.getCapacity() : outputTank.getCapacity(); }
        @Override public boolean isFluidValid(int tank, @NotNull FluidStack stack) { return tank == 0 && inputTank.isFluidValid(stack); }
        @Override public int fill(FluidStack resource, FluidAction action) { return inputTank.fill(resource, action); }
        @Override public @NotNull FluidStack drain(FluidStack resource, FluidAction action) { return outputTank.drain(resource, action); }
        @Override public @NotNull FluidStack drain(int maxDrain, FluidAction action) { return outputTank.drain(maxDrain, action); }
    }
}
