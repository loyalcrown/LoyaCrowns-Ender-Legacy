package com.loyacrown.enderlegacy.registry;

import com.loyacrown.enderlegacy.LoyaCrownsEnderLegacy;
import com.loyacrown.enderlegacy.block.LegacyDarkSteelAnvilBlock;
import com.loyacrown.enderlegacy.block.LegacyEnderIOBlock;
import com.loyacrown.enderlegacy.block.LegacyEnderRailBlock;
import com.loyacrown.enderlegacy.block.LegacyMachineBlock;
import com.loyacrown.enderlegacy.block.LegacyPowerMonitorBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class LegacyBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, LoyaCrownsEnderLegacy.MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, LoyaCrownsEnderLegacy.MOD_ID);
    public static final List<RegistryObject<? extends Item>> ALL_ITEMS = new ArrayList<>();

    private static BlockBehaviour.Properties machineProps() {
        return BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(3.5F).sound(SoundType.METAL);
    }

    public static final RegistryObject<Block> FARMING_STATION = registerBlock("farming_station",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.FARMING_STATION.get()));
    public static final RegistryObject<Block> RESERVOIR = registerBlock("reservoir",
            () -> new LegacyMachineBlock(BlockBehaviour.Properties.copy(Blocks.GLASS).strength(2.0F).noOcclusion(), () -> LegacyBlockEntities.RESERVOIR.get()));
    public static final RegistryObject<Block> COMBUSTION_GENERATOR = registerBlock("combustion_generator",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.COMBUSTION_GENERATOR.get()));
    public static final RegistryObject<Block> ZOMBIE_GENERATOR = registerBlock("zombie_generator",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.ZOMBIE_GENERATOR.get()));
    public static final RegistryObject<Block> PHOTOVOLTAIC_CELL = registerBlock("photovoltaic_cell",
            () -> new LegacyMachineBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(2.5F), () -> LegacyBlockEntities.PHOTOVOLTAIC_CELL.get()));
    public static final RegistryObject<Block> ADVANCED_PHOTOVOLTAIC_CELL = registerBlock("advanced_photovoltaic_cell",
            () -> new LegacyMachineBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(2.5F), () -> LegacyBlockEntities.PHOTOVOLTAIC_CELL.get()));
    public static final RegistryObject<Block> HYPER_CUBE = registerBlock("hyper_cube",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.DIMENSIONAL_TRANSCEIVER.get()));
    public static final RegistryObject<Block> DIMENSIONAL_TRANSCEIVER = registerBlock("dimensional_transceiver",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.DIMENSIONAL_TRANSCEIVER.get()));
    public static final RegistryObject<Block> POWER_MONITOR = registerBlock("power_monitor",
            () -> new LegacyPowerMonitorBlock(machineProps(), () -> LegacyBlockEntities.POWER_MONITOR.get()));
    public static final RegistryObject<Block> THE_VAT = registerBlock("the_vat",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.THE_VAT.get()));
    public static final RegistryObject<Block> WIRELESS_CHARGER = registerBlock("wireless_charger",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.WIRELESS_CHARGER.get()));
    public static final RegistryObject<Block> KILLER_JOE = registerBlock("killer_joe",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.KILLER_JOE.get()));
    public static final RegistryObject<Block> ATTRACTOR_OBELISK = registerBlock("attractor_obelisk",
            () -> new LegacyMachineBlock(BlockBehaviour.Properties.copy(Blocks.OBSIDIAN).strength(5.0F), () -> LegacyBlockEntities.ATTRACTOR_OBELISK.get()));
    public static final RegistryObject<Block> ITEM_BUFFER = registerBlock("item_buffer",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.BUFFER.get()));
    public static final RegistryObject<Block> POWER_BUFFER = registerBlock("power_buffer",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.BUFFER.get()));
    public static final RegistryObject<Block> OMNI_BUFFER = registerBlock("omni_buffer",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.BUFFER.get()));
    public static final RegistryObject<Block> CREATIVE_BUFFER = registerBlock("creative_buffer",
            () -> new LegacyMachineBlock(machineProps(), () -> LegacyBlockEntities.BUFFER.get()));
    public static final RegistryObject<Block> DARK_STEEL_ANVIL = registerBlock("dark_steel_anvil",
            () -> new LegacyDarkSteelAnvilBlock(BlockBehaviour.Properties.copy(Blocks.ANVIL).strength(8.0F, 1200.0F)));
    public static final RegistryObject<Block> PAINTED_CARPET = registerBlock("painted_carpet",
            () -> new CarpetBlock(BlockBehaviour.Properties.copy(Blocks.GRAY_CARPET)));
    public static final RegistryObject<Block> ENDER_RAIL = registerBlock("ender_rail",
            () -> new LegacyEnderRailBlock(BlockBehaviour.Properties.copy(Blocks.POWERED_RAIL).noCollission().strength(0.7F)));
    public static final RegistryObject<Block> LEGACY_ENDER_IO = registerBlock("ender_io",
            () -> new LegacyEnderIOBlock(machineProps()));

    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> supplier) {
        RegistryObject<T> block = BLOCKS.register(name, supplier);
        RegistryObject<Item> item = ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        ALL_ITEMS.add(item);
        return block;
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
    }

    private LegacyBlocks() {}
}
