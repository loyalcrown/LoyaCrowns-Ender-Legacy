package com.loyacrown.enderlegacy.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

public final class EnergyTransferUtil {
    public static void pushEnergy(Level level, BlockPos pos, MutableEnergyStorage storage, int perSideLimit) {
        if (storage.getEnergyStored() <= 0) return;
        for (Direction direction : Direction.values()) {
            var blockEntity = level.getBlockEntity(pos.relative(direction));
            if (blockEntity == null) continue;
            blockEntity.getCapability(ForgeCapabilities.ENERGY, direction.getOpposite()).ifPresent(target -> {
                if (!target.canReceive()) return;
                int available = Math.min(perSideLimit, storage.extractEnergy(perSideLimit, true));
                int accepted = target.receiveEnergy(available, false);
                storage.extractEnergy(accepted, false);
            });
        }
    }

    private EnergyTransferUtil() {}
}
