package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.registry.LegacyBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ReservoirBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity
        implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    private final FluidTank tank = new FluidTank(16_000, stack -> stack.getFluid() == Fluids.WATER) {
        @Override
        protected void onContentsChanged() {
            setChanged();
        }
    };
    private LazyOptional<IFluidHandler> fluidCapability = LazyOptional.empty();
    private boolean primed;

    public ReservoirBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.RESERVOIR.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        fluidCapability = LazyOptional.of(() -> tank);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        fluidCapability.invalidate();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.FLUID_HANDLER) {
            return fluidCapability.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide) return;
        boolean formed = isFormed();
        if (formed && tank.getFluidAmount() >= 2_000) {
            primed = true;
        }
        if (!formed || !primed) return;

        tank.fill(new FluidStack(Fluids.WATER, 50), IFluidHandler.FluidAction.EXECUTE);

        for (Direction direction : Direction.values()) {
            var neighbor = level.getBlockEntity(worldPosition.relative(direction));
            if (neighbor == null) continue;
            neighbor.getCapability(ForgeCapabilities.FLUID_HANDLER, direction.getOpposite()).ifPresent(handler ->
                    FluidUtil.tryFluidTransfer(handler, tank, 50, true));
        }
    }

    private boolean isFormed() {
        if (level == null) return false;
        int[][] corners = {{0, 0}, {-1, 0}, {0, -1}, {-1, -1}};
        for (int[] c : corners) {
            BlockPos base = worldPosition.offset(c[0], 0, c[1]);
            if (isReservoir(base) && isReservoir(base.east()) && isReservoir(base.south()) && isReservoir(base.east().south())) {
                return true;
            }
        }
        return false;
    }

    private boolean isReservoir(BlockPos pos) {
        return level != null && level.getBlockState(pos).is(LegacyBlocks.RESERVOIR.get());
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        // Keep all tank/inventory mutation server-side. The client still returns SUCCESS so
        // the hand animation feels immediate, but the authoritative state changes once.
        if (player.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }

        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.WATER_BUCKET)) {
            int filled = tank.fill(new FluidStack(Fluids.WATER, 1_000), IFluidHandler.FluidAction.EXECUTE);
            if (filled == 1_000) {
                if (!player.getAbilities().instabuild) {
                    player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                }
                if (isFormed() && tank.getFluidAmount() >= 2_000) primed = true;
                player.displayClientMessage(Component.literal("Reservoir: " + tank.getFluidAmount() + " mB water"), true);
                return InteractionResult.CONSUME;
            }
        }
        player.displayClientMessage(Component.literal("Reservoir — " + (isFormed() ? "2x2 formed" : "needs a 2x2")
                + ", " + tank.getFluidAmount() + "/" + tank.getCapacity() + " mB, " + (primed ? "infinite source active" : "add 2 buckets")), true);
        return InteractionResult.CONSUME;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Tank", tank.writeToNBT(new CompoundTag()));
        tag.putBoolean("Primed", primed);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        tank.readFromNBT(tag.getCompound("Tank"));
        primed = tag.getBoolean("Primed");
    }
}
