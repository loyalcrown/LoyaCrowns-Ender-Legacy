package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

public class PowerMonitorBlockEntity extends BlockEntity implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    private int signalStrength;
    private int tickCounter;
    private long stored;
    private long capacity;

    public PowerMonitorBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.POWER_MONITOR.get(), pos, state);
    }

    public int getSignalStrength() {
        return signalStrength;
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide || ++tickCounter < 10) return;
        tickCounter = 0;
        long newStored = 0;
        long newCapacity = 0;
        for (Direction direction : Direction.values()) {
            var be = level.getBlockEntity(worldPosition.relative(direction));
            if (be == null) continue;
            var cap = be.getCapability(ForgeCapabilities.ENERGY, direction.getOpposite()).resolve();
            if (cap.isPresent()) {
                newStored += cap.get().getEnergyStored();
                newCapacity += cap.get().getMaxEnergyStored();
            }
        }
        stored = newStored;
        capacity = newCapacity;
        int newSignal = capacity <= 0 ? 0 : (int) Math.min(15, Math.floor((stored * 15.0) / capacity));
        if (newSignal != signalStrength) {
            signalStrength = newSignal;
            setChanged();
            level.updateNeighborsAt(worldPosition, getBlockState().getBlock());
        }
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        player.displayClientMessage(Component.literal("Power Monitor — " + stored + "/" + capacity
                + " FE | redstone signal " + signalStrength + "/15"), true);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Signal", signalStrength);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        signalStrength = tag.getInt("Signal");
    }
}
