package com.loyacrown.enderlegacy;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.registry.LegacyBlocks;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LoyaCrownsEnderLegacy.MOD_ID)
public final class LoyaCrownsEnderLegacy {
    public static final String MOD_ID = "loyacrowns_ender_legacy";

    public LoyaCrownsEnderLegacy() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        LegacyBlocks.register(modBus);
        LegacyBlockEntities.register(modBus);
        modBus.addListener(this::addCreativeTabContents);
    }

    private void addCreativeTabContents(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            LegacyBlocks.ALL_ITEMS.forEach(item -> event.accept(item.get()));
        }
    }
}
