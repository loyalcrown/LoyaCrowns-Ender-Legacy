package com.loyacrown.enderlegacy.blockentity;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;

public interface LegacyInteractableBlockEntity {
    InteractionResult onUse(Player player, InteractionHand hand);
}
