package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.util.EnergyTransferUtil;
import com.loyacrown.enderlegacy.util.TwoTankFluidHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class CombustionGeneratorBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    private final FluidTank fuelTank = new FluidTank(8_000, this::isFuel) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private final FluidTank coolantTank = new FluidTank(8_000, stack -> stack.getFluid().is(FluidTags.WATER)) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private final TwoTankFluidHandler fluidHandler = new TwoTankFluidHandler(fuelTank, coolantTank);
    private LazyOptional<IFluidHandler> fluidCapability = LazyOptional.empty();
    private int burnCounter;

    public CombustionGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.COMBUSTION_GENERATOR.get(), pos, state, 1_000_000, 0, 8_000);
    }

    private boolean isFuel(FluidStack stack) {
        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(stack.getFluid());
        if (id == null || !"enderio".equals(id.getNamespace())) return false;
        return id.getPath().equals("hootch") || id.getPath().equals("fire_water") || id.getPath().equals("rocket_fuel");
    }

    private int powerPerTick() {
        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(fuelTank.getFluid().getFluid());
        if (id == null) return 0;
        return switch (id.getPath()) {
            case "rocket_fuel" -> 180;
            case "fire_water" -> 120;
            case "hootch" -> 60;
            default -> 0;
        };
    }

    @Override
    public void onLoad() {
        super.onLoad();
        fluidCapability = LazyOptional.of(() -> fluidHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        fluidCapability.invalidate();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.FLUID_HANDLER) return fluidCapability.cast();
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide) return;
        int production = powerPerTick();
        if (production > 0 && !fuelTank.isEmpty() && !coolantTank.isEmpty()
                && energy.getEnergyStored() + production <= energy.getMaxEnergyStored()) {
            energy.addEnergyInternal(production, false);
            if (++burnCounter >= 20) {
                burnCounter = 0;
                fuelTank.drain(1, IFluidHandler.FluidAction.EXECUTE);
                coolantTank.drain(1, IFluidHandler.FluidAction.EXECUTE);
            }
            setChanged();
        }
        EnergyTransferUtil.pushEnergy(level, worldPosition, energy, 2_000);
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (FluidUtil.interactWithFluidHandler(player, hand, fluidHandler)) return InteractionResult.CONSUME;
        player.displayClientMessage(Component.literal("Combustion Generator — " + energy.getEnergyStored() + " FE | fuel "
                + fuelTank.getFluidAmount() + " mB | coolant " + coolantTank.getFluidAmount() + " mB | " + powerPerTick() + " FE/t"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Fuel", fuelTank.writeToNBT(new CompoundTag()));
        tag.put("Coolant", coolantTank.writeToNBT(new CompoundTag()));
        tag.putInt("BurnCounter", burnCounter);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        fuelTank.readFromNBT(tag.getCompound("Fuel"));
        coolantTank.readFromNBT(tag.getCompound("Coolant"));
        burnCounter = tag.getInt("BurnCounter");
    }
}
