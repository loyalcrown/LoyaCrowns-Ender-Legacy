package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

public class WirelessChargerBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    private static final int RANGE = 8;
    private int tickCounter;

    public WirelessChargerBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.WIRELESS_CHARGER.get(), pos, state, 1_000_000, 5_000, 0);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide || ++tickCounter < 5) return;
        tickCounter = 0;
        if (energy.getEnergyStored() <= 0) return;

        for (Player player : level.getEntitiesOfClass(Player.class, new AABB(worldPosition).inflate(RANGE))) {
            for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
                ItemStack stack = player.getInventory().getItem(slot);
                if (stack.isEmpty()) continue;
                stack.getCapability(ForgeCapabilities.ENERGY).ifPresent(target -> {
                    if (energy.getEnergyStored() <= 0 || !target.canReceive()) return;
                    int offer = Math.min(2_000, energy.getEnergyStored());
                    int accepted = target.receiveEnergy(offer, false);
                    energy.removeEnergyInternal(accepted, false);
                    if (accepted > 0) setChanged();
                });
            }
        }
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        player.displayClientMessage(Component.literal("Wireless Charger — " + energy.getEnergyStored() + "/"
                + energy.getMaxEnergyStored() + " FE | charges players within " + RANGE + " blocks"), true);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
