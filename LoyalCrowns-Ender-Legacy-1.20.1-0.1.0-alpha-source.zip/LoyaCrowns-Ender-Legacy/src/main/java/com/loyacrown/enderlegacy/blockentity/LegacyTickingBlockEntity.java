package com.loyacrown.enderlegacy.blockentity;

public interface LegacyTickingBlockEntity {
    void serverTick();
}
