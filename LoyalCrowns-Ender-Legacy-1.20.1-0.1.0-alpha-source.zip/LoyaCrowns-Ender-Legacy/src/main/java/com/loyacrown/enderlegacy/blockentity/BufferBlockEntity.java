package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.registry.LegacyBlocks;
import com.loyacrown.enderlegacy.util.MachineInteractionUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BufferBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity,
        LegacyInteractableBlockEntity, LegacyInventoryHolder {
    private final ItemStackHandler inventory = new ItemStackHandler(9) {
        @Override protected void onContentsChanged(int slot) { setChanged(); }
    };
    private LazyOptional<ItemStackHandler> itemCapability = LazyOptional.empty();

    public BufferBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.BUFFER.get(), pos, state, 1_000_000, 100_000, 100_000);
    }

    private boolean hasItems() {
        return getBlockState().is(LegacyBlocks.ITEM_BUFFER.get())
                || getBlockState().is(LegacyBlocks.OMNI_BUFFER.get())
                || getBlockState().is(LegacyBlocks.CREATIVE_BUFFER.get());
    }

    private boolean hasEnergy() {
        return getBlockState().is(LegacyBlocks.POWER_BUFFER.get())
                || getBlockState().is(LegacyBlocks.OMNI_BUFFER.get())
                || getBlockState().is(LegacyBlocks.CREATIVE_BUFFER.get());
    }

    private boolean isCreative() {
        return getBlockState().is(LegacyBlocks.CREATIVE_BUFFER.get());
    }

    @Override
    public void onLoad() {
        super.onLoad();
        itemCapability = LazyOptional.of(() -> inventory);
    }

    @Override
    public void invalidateCaps() {
        itemCapability.invalidate();
        super.invalidateCaps();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return hasItems() ? itemCapability.cast() : LazyOptional.empty();
        }
        if (cap == ForgeCapabilities.ENERGY && !hasEnergy()) {
            return LazyOptional.empty();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (isCreative() && energy.getEnergyStored() < energy.getMaxEnergyStored()) {
            energy.setEnergyStored(energy.getMaxEnergyStored());
            setChanged();
        }
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        String name = getBlockState().is(LegacyBlocks.ITEM_BUFFER.get()) ? "Item Buffer"
                : getBlockState().is(LegacyBlocks.POWER_BUFFER.get()) ? "Power Buffer"
                : getBlockState().is(LegacyBlocks.CREATIVE_BUFFER.get()) ? "Creative Buffer" : "Omni Buffer";
        String status = name + " — " + (hasEnergy() ? energy.getEnergyStored() + "/" + energy.getMaxEnergyStored() + " FE" : "item storage");
        if (hasItems() && (!player.getItemInHand(hand).isEmpty() || player.isShiftKeyDown())) {
            return MachineInteractionUtil.insertOrExtract(player, hand, inventory, status);
        }
        player.displayClientMessage(Component.literal(status), true);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    @Override
    public ItemStackHandler getInventory() {
        return inventory;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inventory", inventory.serializeNBT());
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        inventory.deserializeNBT(tag.getCompound("Inventory"));
    }
}
