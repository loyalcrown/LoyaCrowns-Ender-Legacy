package com.loyacrown.enderlegacy.block;

import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class LegacyDarkSteelAnvilBlock extends AnvilBlock {
    public LegacyDarkSteelAnvilBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}
