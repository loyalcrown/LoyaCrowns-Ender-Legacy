package com.loyacrown.enderlegacy.registry;

import com.loyacrown.enderlegacy.LoyaCrownsEnderLegacy;
import com.loyacrown.enderlegacy.blockentity.*;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class LegacyBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, LoyaCrownsEnderLegacy.MOD_ID);

    public static final RegistryObject<BlockEntityType<FarmingStationBlockEntity>> FARMING_STATION = BLOCK_ENTITIES.register("farming_station",
            () -> BlockEntityType.Builder.of(FarmingStationBlockEntity::new, LegacyBlocks.FARMING_STATION.get()).build(null));
    public static final RegistryObject<BlockEntityType<ReservoirBlockEntity>> RESERVOIR = BLOCK_ENTITIES.register("reservoir",
            () -> BlockEntityType.Builder.of(ReservoirBlockEntity::new, LegacyBlocks.RESERVOIR.get()).build(null));
    public static final RegistryObject<BlockEntityType<CombustionGeneratorBlockEntity>> COMBUSTION_GENERATOR = BLOCK_ENTITIES.register("combustion_generator",
            () -> BlockEntityType.Builder.of(CombustionGeneratorBlockEntity::new, LegacyBlocks.COMBUSTION_GENERATOR.get()).build(null));
    public static final RegistryObject<BlockEntityType<ZombieGeneratorBlockEntity>> ZOMBIE_GENERATOR = BLOCK_ENTITIES.register("zombie_generator",
            () -> BlockEntityType.Builder.of(ZombieGeneratorBlockEntity::new, LegacyBlocks.ZOMBIE_GENERATOR.get()).build(null));
    public static final RegistryObject<BlockEntityType<PhotovoltaicCellBlockEntity>> PHOTOVOLTAIC_CELL = BLOCK_ENTITIES.register("photovoltaic_cell",
            () -> BlockEntityType.Builder.of(PhotovoltaicCellBlockEntity::new, LegacyBlocks.PHOTOVOLTAIC_CELL.get(), LegacyBlocks.ADVANCED_PHOTOVOLTAIC_CELL.get()).build(null));
    public static final RegistryObject<BlockEntityType<DimensionalTransceiverBlockEntity>> DIMENSIONAL_TRANSCEIVER = BLOCK_ENTITIES.register("dimensional_transceiver",
            () -> BlockEntityType.Builder.of(DimensionalTransceiverBlockEntity::new,
                    LegacyBlocks.DIMENSIONAL_TRANSCEIVER.get(), LegacyBlocks.HYPER_CUBE.get()).build(null));
    public static final RegistryObject<BlockEntityType<PowerMonitorBlockEntity>> POWER_MONITOR = BLOCK_ENTITIES.register("power_monitor",
            () -> BlockEntityType.Builder.of(PowerMonitorBlockEntity::new, LegacyBlocks.POWER_MONITOR.get()).build(null));
    public static final RegistryObject<BlockEntityType<VatBlockEntity>> THE_VAT = BLOCK_ENTITIES.register("the_vat",
            () -> BlockEntityType.Builder.of(VatBlockEntity::new, LegacyBlocks.THE_VAT.get()).build(null));
    public static final RegistryObject<BlockEntityType<WirelessChargerBlockEntity>> WIRELESS_CHARGER = BLOCK_ENTITIES.register("wireless_charger",
            () -> BlockEntityType.Builder.of(WirelessChargerBlockEntity::new, LegacyBlocks.WIRELESS_CHARGER.get()).build(null));
    public static final RegistryObject<BlockEntityType<KillerJoeBlockEntity>> KILLER_JOE = BLOCK_ENTITIES.register("killer_joe",
            () -> BlockEntityType.Builder.of(KillerJoeBlockEntity::new, LegacyBlocks.KILLER_JOE.get()).build(null));
    public static final RegistryObject<BlockEntityType<AttractorObeliskBlockEntity>> ATTRACTOR_OBELISK = BLOCK_ENTITIES.register("attractor_obelisk",
            () -> BlockEntityType.Builder.of(AttractorObeliskBlockEntity::new, LegacyBlocks.ATTRACTOR_OBELISK.get()).build(null));
    public static final RegistryObject<BlockEntityType<BufferBlockEntity>> BUFFER = BLOCK_ENTITIES.register("buffer",
            () -> BlockEntityType.Builder.of(BufferBlockEntity::new,
                    LegacyBlocks.ITEM_BUFFER.get(), LegacyBlocks.POWER_BUFFER.get(), LegacyBlocks.OMNI_BUFFER.get(), LegacyBlocks.CREATIVE_BUFFER.get()).build(null));

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
    }

    private LegacyBlockEntities() {}
}
