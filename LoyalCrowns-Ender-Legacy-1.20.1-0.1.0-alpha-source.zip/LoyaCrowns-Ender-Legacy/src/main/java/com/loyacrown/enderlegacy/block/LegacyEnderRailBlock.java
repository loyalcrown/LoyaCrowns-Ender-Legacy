package com.loyacrown.enderlegacy.block;

import com.loyacrown.enderlegacy.blockentity.DimensionalTransceiverBlockEntity;
import com.loyacrown.enderlegacy.registry.LegacyBlocks;
import com.loyacrown.enderlegacy.util.DimensionalTransceiverNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.PoweredRailBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class LegacyEnderRailBlock extends PoweredRailBlock {
    private static final String COOLDOWN_KEY = "LoyaCrownEnderRailCooldown";

    public LegacyEnderRailBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        super.entityInside(state, level, pos, entity);
        if (level.isClientSide || !(entity instanceof AbstractMinecart cart)) return;
        long now = level.getGameTime();
        if (cart.getPersistentData().getLong(COOLDOWN_KEY) > now) return;
        if (!(level.getBlockEntity(pos.below()) instanceof DimensionalTransceiverBlockEntity source)) return;

        DimensionalTransceiverBlockEntity destination = DimensionalTransceiverNetwork.findPeer(source,
                peer -> peer.acceptsIncoming() && peer.getLevel() != null
                        && peer.getLevel().getBlockState(peer.getBlockPos().above()).is(LegacyBlocks.ENDER_RAIL.get()));
        if (destination == null || !(destination.getLevel() instanceof ServerLevel destinationLevel)) return;

        BlockPos targetPos = destination.getBlockPos().above();
        Vec3 velocity = cart.getDeltaMovement();
        cart.getPersistentData().putLong(COOLDOWN_KEY, now + 40);
        if (destinationLevel == level) {
            cart.setPos(targetPos.getX() + 0.5, targetPos.getY() + 0.1, targetPos.getZ() + 0.5);
            cart.setDeltaMovement(velocity);
        } else {
            Entity moved = cart.changeDimension(destinationLevel);
            if (moved != null) {
                moved.setPos(targetPos.getX() + 0.5, targetPos.getY() + 0.1, targetPos.getZ() + 0.5);
                moved.setDeltaMovement(velocity);
                moved.getPersistentData().putLong(COOLDOWN_KEY, destinationLevel.getGameTime() + 40);
            }
        }
    }
}
