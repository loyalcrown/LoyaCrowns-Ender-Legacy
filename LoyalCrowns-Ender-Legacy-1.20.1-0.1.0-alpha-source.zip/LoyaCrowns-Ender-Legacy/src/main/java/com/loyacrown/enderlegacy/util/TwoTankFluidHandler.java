package com.loyacrown.enderlegacy.util;

import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import org.jetbrains.annotations.NotNull;

public class TwoTankFluidHandler implements IFluidHandler {
    private final FluidTank first;
    private final FluidTank second;

    public TwoTankFluidHandler(FluidTank first, FluidTank second) {
        this.first = first;
        this.second = second;
    }

    @Override
    public int getTanks() {
        return 2;
    }

    private FluidTank tank(int index) {
        return index == 0 ? first : second;
    }

    @Override
    public @NotNull FluidStack getFluidInTank(int tank) {
        return tank(tank).getFluid();
    }

    @Override
    public int getTankCapacity(int tank) {
        return tank(tank).getCapacity();
    }

    @Override
    public boolean isFluidValid(int tank, @NotNull FluidStack stack) {
        return tank(tank).isFluidValid(stack);
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (first.isFluidValid(resource)) return first.fill(resource, action);
        if (second.isFluidValid(resource)) return second.fill(resource, action);
        return 0;
    }

    @Override
    public @NotNull FluidStack drain(FluidStack resource, FluidAction action) {
        if (!first.getFluid().isEmpty() && first.getFluid().isFluidEqual(resource)) return first.drain(resource, action);
        if (!second.getFluid().isEmpty() && second.getFluid().isFluidEqual(resource)) return second.drain(resource, action);
        return FluidStack.EMPTY;
    }

    @Override
    public @NotNull FluidStack drain(int maxDrain, FluidAction action) {
        if (!first.isEmpty()) return first.drain(maxDrain, action);
        if (!second.isEmpty()) return second.drain(maxDrain, action);
        return FluidStack.EMPTY;
    }
}
