package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.util.DimensionalTransceiverNetwork;
import com.loyacrown.enderlegacy.util.MachineInteractionUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DimensionalTransceiverBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity,
        LegacyInteractableBlockEntity, LegacyInventoryHolder {
    public enum Mode { SEND, RECEIVE, BOTH }

    private final ItemStackHandler inventory = new ItemStackHandler(9) {
        @Override protected void onContentsChanged(int slot) { setChanged(); }
    };
    private final FluidTank fluidTank = new FluidTank(16_000) {
        @Override protected void onContentsChanged() { setChanged(); }
    };
    private LazyOptional<ItemStackHandler> itemCapability = LazyOptional.empty();
    private LazyOptional<IFluidHandler> fluidCapability = LazyOptional.empty();
    private String channel = "default";
    private Mode mode = Mode.BOTH;
    private int tickCounter;
    private boolean registered;

    public DimensionalTransceiverBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.DIMENSIONAL_TRANSCEIVER.get(), pos, state, 1_000_000, 10_000, 10_000);
    }

    public MinecraftServer getServer() {
        return level == null ? null : level.getServer();
    }

    public String getChannel() {
        return channel;
    }

    public Mode getMode() {
        return mode;
    }

    public boolean acceptsIncoming() {
        return mode == Mode.RECEIVE || mode == Mode.BOTH;
    }

    @Override
    public void onLoad() {
        super.onLoad();
        itemCapability = LazyOptional.of(() -> inventory);
        fluidCapability = LazyOptional.of(() -> fluidTank);
        registerNetwork();
    }

    private void registerNetwork() {
        if (level != null && !level.isClientSide) {
            DimensionalTransceiverNetwork.register(this);
            registered = true;
        }
    }

    @Override
    public void setRemoved() {
        DimensionalTransceiverNetwork.unregister(this);
        super.setRemoved();
    }

    @Override
    public void invalidateCaps() {
        itemCapability.invalidate();
        fluidCapability.invalidate();
        super.invalidateCaps();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return itemCapability.cast();
        if (cap == ForgeCapabilities.FLUID_HANDLER) return fluidCapability.cast();
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide) return;
        if (!registered) registerNetwork();
        if (++tickCounter < 5) return;
        tickCounter = 0;
        if (mode == Mode.RECEIVE) return;

        DimensionalTransceiverBlockEntity peer = DimensionalTransceiverNetwork.findPeer(this, DimensionalTransceiverBlockEntity::acceptsIncoming);
        if (peer == null) return;
        transferEnergy(peer);
        transferFluid(peer);
        transferItems(peer);
    }

    private void transferEnergy(DimensionalTransceiverBlockEntity peer) {
        int offered = energy.extractEnergy(5_000, true);
        int accepted = peer.energy.receiveEnergy(offered, false);
        energy.extractEnergy(accepted, false);
        if (accepted > 0) {
            setChanged();
            peer.setChanged();
        }
    }

    private void transferFluid(DimensionalTransceiverBlockEntity peer) {
        if (fluidTank.isEmpty()) return;
        FluidStack offered = fluidTank.drain(250, IFluidHandler.FluidAction.SIMULATE);
        int accepted = peer.fluidTank.fill(offered, IFluidHandler.FluidAction.EXECUTE);
        if (accepted > 0) {
            fluidTank.drain(accepted, IFluidHandler.FluidAction.EXECUTE);
            setChanged();
            peer.setChanged();
        }
    }

    private void transferItems(DimensionalTransceiverBlockEntity peer) {
        for (int i = 0; i < inventory.getSlots(); i++) {
            ItemStack source = inventory.extractItem(i, 8, true);
            if (source.isEmpty()) continue;
            ItemStack remainder = ItemHandlerHelper.insertItemStacked(peer.inventory, source.copy(), false);
            int moved = source.getCount() - remainder.getCount();
            if (moved > 0) {
                inventory.extractItem(i, moved, false);
                setChanged();
                peer.setChanged();
                return;
            }
        }
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if ((held.is(Items.NAME_TAG) || held.is(Items.PAPER)) && held.hasCustomHoverName()) {
            if (!player.level().isClientSide) {
                DimensionalTransceiverNetwork.unregister(this);
                channel = held.getHoverName().getString().trim();
                if (channel.isBlank()) channel = "default";
                registerNetwork();
                setChanged();
                player.displayClientMessage(Component.literal("Dimensional Transceiver channel set to: " + channel), true);
            }
            return InteractionResult.sidedSuccess(player.level().isClientSide);
        }
        if (held.isEmpty() && player.isShiftKeyDown()) {
            if (!player.level().isClientSide) {
                mode = switch (mode) {
                    case SEND -> Mode.RECEIVE;
                    case RECEIVE -> Mode.BOTH;
                    case BOTH -> Mode.SEND;
                };
                setChanged();
                player.displayClientMessage(Component.literal("Dimensional Transceiver mode: " + mode), true);
            }
            return InteractionResult.sidedSuccess(player.level().isClientSide);
        }
        if (held.isEmpty()) {
            player.displayClientMessage(Component.literal("Dimensional Transceiver — channel " + channel + " | " + mode
                    + " | " + energy.getEnergyStored() + " FE | " + fluidTank.getFluidAmount() + " mB | " + countItems() + " items"), true);
            return InteractionResult.sidedSuccess(player.level().isClientSide);
        }
        return MachineInteractionUtil.insertOrExtract(player, hand, inventory,
                "Dimensional Transceiver — channel " + channel + " | " + mode);
    }

    private int countItems() {
        int count = 0;
        for (int i = 0; i < inventory.getSlots(); i++) count += inventory.getStackInSlot(i).getCount();
        return count;
    }

    @Override
    public ItemStackHandler getInventory() {
        return inventory;
    }

    public FluidTank getFluidTank() {
        return fluidTank;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("Channel", channel);
        tag.putString("Mode", mode.name());
        tag.put("Inventory", inventory.serializeNBT());
        tag.put("Fluid", fluidTank.writeToNBT(new CompoundTag()));
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        channel = tag.contains("Channel") ? tag.getString("Channel") : "default";
        try {
            mode = Mode.valueOf(tag.getString("Mode"));
        } catch (IllegalArgumentException ignored) {
            mode = Mode.BOTH;
        }
        inventory.deserializeNBT(tag.getCompound("Inventory"));
        fluidTank.readFromNBT(tag.getCompound("Fluid"));
    }
}
