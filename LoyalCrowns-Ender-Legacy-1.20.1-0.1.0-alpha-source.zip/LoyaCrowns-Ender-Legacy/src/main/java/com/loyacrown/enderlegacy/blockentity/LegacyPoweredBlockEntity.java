package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.util.MutableEnergyStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.IEnergyStorage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class LegacyPoweredBlockEntity extends BlockEntity {
    protected final MutableEnergyStorage energy;
    private LazyOptional<IEnergyStorage> energyCapability = LazyOptional.empty();

    protected LegacyPoweredBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state,
                                       int capacity, int maxReceive, int maxExtract) {
        super(type, pos, state);
        this.energy = new MutableEnergyStorage(capacity, maxReceive, maxExtract);
    }

    public MutableEnergyStorage energy() {
        return energy;
    }

    @Override
    public void onLoad() {
        super.onLoad();
        energyCapability = LazyOptional.of(() -> energy);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        energyCapability.invalidate();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ENERGY) {
            return energyCapability.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Energy", energy.getEnergyStored());
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        energy.setEnergyStored(tag.getInt("Energy"));
    }
}
