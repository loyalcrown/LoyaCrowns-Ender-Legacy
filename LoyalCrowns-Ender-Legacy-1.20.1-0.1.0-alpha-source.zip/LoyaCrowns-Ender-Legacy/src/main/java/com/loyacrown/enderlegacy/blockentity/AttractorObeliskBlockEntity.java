package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class AttractorObeliskBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    private static final int RANGE = 16;
    private int tickCounter;
    private boolean hostileOnly = true;

    public AttractorObeliskBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.ATTRACTOR_OBELISK.get(), pos, state, 100_000, 1_000, 0);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide || ++tickCounter < 5) return;
        tickCounter = 0;
        if (energy.getEnergyStored() < 5) return;

        List<Mob> mobs = level.getEntitiesOfClass(Mob.class, new AABB(worldPosition).inflate(RANGE), mob ->
                mob.isAlive() && (!hostileOnly || mob instanceof Monster));
        Vec3 target = Vec3.atCenterOf(worldPosition).add(0, 0.5, 0);
        for (Mob mob : mobs) {
            if (energy.getEnergyStored() < 5) break;
            Vec3 delta = target.subtract(mob.position());
            double distance = Math.max(1.0, delta.length());
            Vec3 pull = delta.scale(0.08 / distance);
            mob.setDeltaMovement(mob.getDeltaMovement().add(pull.x, Math.min(0.06, pull.y + 0.01), pull.z));
            energy.removeEnergyInternal(5, false);
        }
        if (!mobs.isEmpty()) setChanged();
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        if (player.isShiftKeyDown() && player.getItemInHand(hand).isEmpty()) {
            if (!player.level().isClientSide) {
                hostileOnly = !hostileOnly;
                setChanged();
            }
        }
        player.displayClientMessage(Component.literal("Attractor Obelisk — " + energy.getEnergyStored() + " FE | range "
                + RANGE + " | targets " + (hostileOnly ? "hostile mobs" : "all mobs")), true);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("HostileOnly", hostileOnly);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        hostileOnly = !tag.contains("HostileOnly") || tag.getBoolean("HostileOnly");
    }
}
