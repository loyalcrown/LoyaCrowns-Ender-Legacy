package com.loyacrown.enderlegacy.blockentity;

import net.minecraftforge.items.ItemStackHandler;

public interface LegacyInventoryHolder {
    ItemStackHandler getInventory();
}
