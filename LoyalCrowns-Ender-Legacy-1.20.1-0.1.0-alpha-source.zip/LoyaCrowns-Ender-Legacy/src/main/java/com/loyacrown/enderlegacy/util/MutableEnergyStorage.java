package com.loyacrown.enderlegacy.util;

import net.minecraftforge.energy.EnergyStorage;

public class MutableEnergyStorage extends EnergyStorage {
    public MutableEnergyStorage(int capacity, int maxReceive, int maxExtract) {
        super(capacity, maxReceive, maxExtract);
    }

    public int addEnergyInternal(int amount, boolean simulate) {
        int accepted = Math.min(capacity - energy, Math.max(0, amount));
        if (!simulate) {
            energy += accepted;
        }
        return accepted;
    }

    public int removeEnergyInternal(int amount, boolean simulate) {
        int extracted = Math.min(energy, Math.max(0, amount));
        if (!simulate) {
            energy -= extracted;
        }
        return extracted;
    }

    public void setEnergyStored(int amount) {
        energy = Math.max(0, Math.min(capacity, amount));
    }
}
