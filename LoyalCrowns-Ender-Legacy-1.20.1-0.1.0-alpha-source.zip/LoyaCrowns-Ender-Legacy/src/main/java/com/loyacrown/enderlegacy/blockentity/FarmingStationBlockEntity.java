package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.util.MachineInteractionUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class FarmingStationBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity,
        LegacyInteractableBlockEntity, LegacyInventoryHolder {
    private static final int ENERGY_PER_ACTION = 120;
    private static final int RANGE = 4;

    private final ItemStackHandler inventory = new ItemStackHandler(12) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };
    private LazyOptional<ItemStackHandler> itemCapability = LazyOptional.empty();
    private int tickCounter;
    private int scanIndex;

    public FarmingStationBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.FARMING_STATION.get(), pos, state, 100_000, 2_000, 0);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        itemCapability = LazyOptional.of(() -> inventory);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        itemCapability.invalidate();
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return itemCapability.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void serverTick() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        if (++tickCounter < 10) {
            return;
        }
        tickCounter = 0;
        if (energy.getEnergyStored() < ENERGY_PER_ACTION) {
            return;
        }

        int diameter = RANGE * 2 + 1;
        int total = diameter * diameter;
        for (int attempt = 0; attempt < 10; attempt++) {
            int idx = scanIndex++ % total;
            int dx = (idx % diameter) - RANGE;
            int dz = (idx / diameter) - RANGE;
            BlockPos target = worldPosition.offset(dx, 0, dz);
            if (harvest(serverLevel, target) || plant(serverLevel, target)) {
                energy.removeEnergyInternal(ENERGY_PER_ACTION, false);
                setChanged();
                break;
            }
        }
    }

    private boolean harvest(ServerLevel serverLevel, BlockPos pos) {
        BlockState state = serverLevel.getBlockState(pos);
        if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)) {
            List<ItemStack> drops = Block.getDrops(state, serverLevel, pos, serverLevel.getBlockEntity(pos));
            serverLevel.setBlock(pos, crop.getStateForAge(0), Block.UPDATE_ALL);
            storeDrops(serverLevel, pos, drops);
            return true;
        }
        if (state.is(Blocks.NETHER_WART) && state.getValue(NetherWartBlock.AGE) >= NetherWartBlock.MAX_AGE) {
            List<ItemStack> drops = Block.getDrops(state, serverLevel, pos, serverLevel.getBlockEntity(pos));
            serverLevel.setBlock(pos, state.setValue(NetherWartBlock.AGE, 0), Block.UPDATE_ALL);
            storeDrops(serverLevel, pos, drops);
            return true;
        }
        if (state.getBlock() instanceof CocoaBlock && state.getValue(CocoaBlock.AGE) >= CocoaBlock.MAX_AGE) {
            List<ItemStack> drops = Block.getDrops(state, serverLevel, pos, serverLevel.getBlockEntity(pos));
            serverLevel.setBlock(pos, state.setValue(CocoaBlock.AGE, 0), Block.UPDATE_ALL);
            storeDrops(serverLevel, pos, drops);
            return true;
        }
        return false;
    }

    private boolean plant(ServerLevel serverLevel, BlockPos plantPos) {
        if (!serverLevel.getBlockState(plantPos).isAir()) {
            return false;
        }
        BlockState soil = serverLevel.getBlockState(plantPos.below());

        if (soil.is(Blocks.FARMLAND)) {
            return tryPlant(serverLevel, plantPos, Items.WHEAT_SEEDS, Blocks.WHEAT.defaultBlockState())
                    || tryPlant(serverLevel, plantPos, Items.CARROT, Blocks.CARROTS.defaultBlockState())
                    || tryPlant(serverLevel, plantPos, Items.POTATO, Blocks.POTATOES.defaultBlockState())
                    || tryPlant(serverLevel, plantPos, Items.BEETROOT_SEEDS, Blocks.BEETROOTS.defaultBlockState());
        }
        if (soil.is(Blocks.SOUL_SAND)) {
            return tryPlant(serverLevel, plantPos, Items.NETHER_WART, Blocks.NETHER_WART.defaultBlockState());
        }
        return false;
    }

    private boolean tryPlant(ServerLevel level, BlockPos pos, Item seed, BlockState plantedState) {
        for (int slot = 0; slot < inventory.getSlots(); slot++) {
            ItemStack stack = inventory.getStackInSlot(slot);
            if (stack.is(seed)) {
                inventory.extractItem(slot, 1, false);
                level.setBlock(pos, plantedState, Block.UPDATE_ALL);
                return true;
            }
        }
        return false;
    }

    private void storeDrops(ServerLevel serverLevel, BlockPos pos, List<ItemStack> drops) {
        for (ItemStack drop : drops) {
            ItemStack remainder = ItemHandlerHelper.insertItemStacked(inventory, drop, false);
            if (!remainder.isEmpty()) {
                Block.popResource(serverLevel, pos, remainder);
            }
        }
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        String status = "Farming Station — " + energy.getEnergyStored() + "/" + energy.getMaxEnergyStored()
                + " FE, range " + RANGE + ", inventory " + countFilledSlots() + "/" + inventory.getSlots();
        if (player.getItemInHand(hand).isEmpty() && !player.isShiftKeyDown()) {
            player.displayClientMessage(Component.literal(status), true);
            return InteractionResult.sidedSuccess(player.level().isClientSide);
        }
        return MachineInteractionUtil.insertOrExtract(player, hand, inventory, status);
    }

    private int countFilledSlots() {
        int count = 0;
        for (int i = 0; i < inventory.getSlots(); i++) {
            if (!inventory.getStackInSlot(i).isEmpty()) count++;
        }
        return count;
    }

    @Override
    public ItemStackHandler getInventory() {
        return inventory;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inventory", inventory.serializeNBT());
        tag.putInt("ScanIndex", scanIndex);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        inventory.deserializeNBT(tag.getCompound("Inventory"));
        scanIndex = tag.getInt("ScanIndex");
    }
}
