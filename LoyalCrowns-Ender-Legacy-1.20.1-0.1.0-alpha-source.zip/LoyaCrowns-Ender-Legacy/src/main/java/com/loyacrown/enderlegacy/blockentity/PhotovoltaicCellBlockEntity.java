package com.loyacrown.enderlegacy.blockentity;

import com.loyacrown.enderlegacy.registry.LegacyBlockEntities;
import com.loyacrown.enderlegacy.registry.LegacyBlocks;
import com.loyacrown.enderlegacy.util.EnergyTransferUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;

public class PhotovoltaicCellBlockEntity extends LegacyPoweredBlockEntity implements LegacyTickingBlockEntity, LegacyInteractableBlockEntity {
    public PhotovoltaicCellBlockEntity(BlockPos pos, BlockState state) {
        super(LegacyBlockEntities.PHOTOVOLTAIC_CELL.get(), pos, state, 200_000, 0, 4_000);
    }

    private int generationRate() {
        return getBlockState().is(LegacyBlocks.ADVANCED_PHOTOVOLTAIC_CELL.get()) ? 160 : 40;
    }

    private boolean hasSun() {
        if (level == null) return false;
        BlockPos skyPos = worldPosition.above();
        return level.isDay() && level.canSeeSky(skyPos) && !level.isRainingAt(skyPos);
    }

    @Override
    public void serverTick() {
        if (level == null || level.isClientSide) return;
        if (hasSun()) {
            energy.addEnergyInternal(generationRate(), false);
            setChanged();
        }
        EnergyTransferUtil.pushEnergy(level, worldPosition, energy, 1_000);
    }

    @Override
    public InteractionResult onUse(Player player, InteractionHand hand) {
        player.displayClientMessage(Component.literal((getBlockState().is(LegacyBlocks.ADVANCED_PHOTOVOLTAIC_CELL.get())
                ? "Advanced Photovoltaic Cell" : "Photovoltaic Cell") + " — " + energy.getEnergyStored()
                + " FE | " + (hasSun() ? generationRate() + " FE/t" : "no sunlight")), true);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
