# Build notes

## Intended runtime

- Minecraft 1.20.1
- Forge 47.4.0 or newer in the 47.x line
- Ender IO 6.2.15-beta
- Java 17

## Build command

With Gradle 8.8 available:

```bash
gradle --no-daemon clean build
```

The reobfuscated mod JAR should be written to `build/libs/`.

## GitHub Actions

This source snapshot includes `.github/workflows/build.yml`. Push the project to a GitHub repository and run the **Build LoyaCrown's Ender Legacy** workflow. The workflow uses Java 17 and Gradle 8.8 and uploads `build/libs/*.jar` as an artifact.

## Current verification level

The source snapshot has passed these offline checks:

- all 106 JSON resource files parse successfully;
- all 21 registered blocks have blockstate, block model, item model, and loot table resources;
- all survival blocks have recipes (Creative Buffer intentionally has no survival recipe);
- Ender IO IDs referenced by the recipes/resources were found in the supplied Ender IO 6.2.15-beta JAR;
- a dependency-free `javac` parser pass found no Java syntax/parser errors.

A full Forge compilation and runtime launch is still required. The development environment used to prepare this snapshot cannot download Forge/Gradle dependencies, so this is not yet represented as a tested release JAR.

## Test safely

Build and launch in a disposable test instance/world first. See `TESTING.md`.
