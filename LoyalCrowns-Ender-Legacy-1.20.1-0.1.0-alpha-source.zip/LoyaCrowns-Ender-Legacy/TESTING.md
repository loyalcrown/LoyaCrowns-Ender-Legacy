# Alpha test checklist

Use a disposable world first.

1. Confirm Forge reports Minecraft 1.20.1, Forge 47.4.x and Ender IO 6.2.15-beta.
2. Confirm all LoyaCrown's Ender Legacy blocks appear in the Functional Blocks creative tab.
3. Place/break every restored block and confirm it drops itself where expected.
4. Test Farming Station with wheat, carrots, potatoes, beetroot and nether wart.
5. Form a 2x2 Reservoir, insert two water buckets, and connect a fluid consumer.
6. Fill generators with the matching Ender IO fluids and confirm FE output.
7. Put two Dimensional Transceivers on the same named channel and test item/fluid/FE movement, then repeat across dimensions with both chunks loaded.
8. Put Ender Rail above both same-channel transceivers and test a minecart in a disposable world.
9. Test Killer Joe with a basic sword before trying valuable enchanted gear.
10. Check server/client logs for exceptions before moving the mod into an important world.
