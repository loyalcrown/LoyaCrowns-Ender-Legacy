# Port status — LoyaCrown's Ender Legacy 0.1.0-alpha

## Restored because they are absent from Ender IO 6.2.15-beta

| Legacy block | New ID | Alpha status |
| --- | --- | --- |
| Farming Station | `loyacrowns_ender_legacy:farming_station` | Functional alpha: vanilla crops/nether wart; powered; internal inventory. Modded crop/tool/capacitor behavior still needs parity work. |
| Reservoir | `loyacrowns_ender_legacy:reservoir` | Functional alpha: 2x2 detection, two-bucket priming, infinite-water generation and adjacent fluid output. |
| Combustion Generator | `loyacrowns_ender_legacy:combustion_generator` | Functional alpha: Ender IO Hootch/Fire Water/Rocket Fuel + water coolant -> FE. |
| Zombie Generator | `loyacrowns_ender_legacy:zombie_generator` | Functional alpha: Nutrient Distillation -> FE. |
| Photovoltaic Cell | `loyacrowns_ender_legacy:photovoltaic_cell` | Functional alpha: daylight FE generation. |
| Advanced Photovoltaic Cell | `loyacrowns_ender_legacy:advanced_photovoltaic_cell` | Functional alpha: higher daylight FE generation. |
| Hyper Cube / deprecated Dimensional Transceiver | `loyacrowns_ender_legacy:hyper_cube` | Restored as the deprecated legacy variant and shares the new transceiver network implementation. Crafting conversion to the newer transceiver is included. |
| Dimensional Transceiver | `loyacrowns_ender_legacy:dimensional_transceiver` | Functional alpha: named channels, send/receive/both, cross-dimension loaded-node transfer of FE/fluids/items. Legacy GUI, public/private channel lists and filters are not yet recreated. |
| Power Monitor | `loyacrowns_ender_legacy:power_monitor` | Functional alpha: samples adjacent FE storage and emits redstone/comparator strength. Full conduit-network monitor parity remains. |
| The Vat | `loyacrowns_ender_legacy:the_vat` | Functional alpha: legacy-style Ender IO fluid brewing for Nutrient Distillation, Hootch, Rocket Fuel and Fire Water. |
| Wireless Charger | `loyacrowns_ender_legacy:wireless_charger` | Functional alpha: charges Forge Energy items carried by nearby players. |
| Killer Joe | `loyacrowns_ender_legacy:killer_joe` | Functional alpha: sword slot, Nutrient Distillation consumption, mob attacks, XP Juice collection. Needs live-server verification of fake-player interactions. |
| Attractor Obelisk | `loyacrowns_ender_legacy:attractor_obelisk` | Functional alpha: powered mob attraction. Soul-vial-specific filtering is not yet recreated. |
| Item Buffer | `loyacrowns_ender_legacy:item_buffer` | Functional alpha storage capability. Legacy GUI/side configuration is not yet recreated. |
| Power Buffer | `loyacrowns_ender_legacy:power_buffer` | Functional alpha FE capability. |
| Omni Buffer | `loyacrowns_ender_legacy:omni_buffer` | Functional alpha item + FE capability. |
| Creative Buffer | `loyacrowns_ender_legacy:creative_buffer` | Alpha: creative FE source plus item storage. No survival recipe by design. |
| Dark Steel Anvil | `loyacrowns_ender_legacy:dark_steel_anvil` | Uses vanilla anvil behavior with Dark Steel durability properties. Legacy damage-resistance parity needs runtime verification. |
| Painted Carpet | `loyacrowns_ender_legacy:painted_carpet` | Block restored. Dynamic Painting Machine appearance-copy behavior is still pending. |
| Ender Rail | `loyacrowns_ender_legacy:ender_rail` | Functional alpha: minecart transfer between same-channel transceivers, including dimensions. Needs runtime rail-shape/teleport testing. |
| Ender IO remote-access block | `loyacrowns_ender_legacy:ender_io` | Functional alpha: opens a nearby machine MenuProvider; full Staff of Travel/Travel Anchor remote-access parity remains. |

## Not duplicated because Ender IO 6.2.15-beta already contains the modern equivalent

Legacy `2.2.8.381` included these blocks, but the target 1.20.1 Ender IO JAR already supplies their same or successor function:

- Fused Quartz / clear-glass family
- Dark Steel Bars
- Stirling Generator
- Alloy Smelter
- Capacitor Banks
- SAG Mill
- Fluid Tank
- Crafter
- Vacuum Chest
- Enchanter
- Soul Binder
- Slice'N'Splice
- Aversion/Spawn Guard Obelisk
- Experience Obelisk
- Powered Spawner
- Electric/Powered Lights and Light Node
- Dark Steel Pressure Plate
- Dark Steel Ladder
- Reinforced Obsidian
- Alloy storage blocks
- Painting Machine
- Painted Fence / Fence Gate / Wall / Stairs / Slab / Glowstone
- Travel Anchor
- Enderman Head

This avoids recipe/registry confusion and lets the modern Ender IO implementation remain authoritative for content it already restored.
